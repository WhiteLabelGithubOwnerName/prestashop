<?php
/**
 * WhiteLabelName SDK
 *
 * This library allows to interact with the WhiteLabelName payment service.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */


namespace WhiteLabelMachineName\Sdk\Service;

use WhiteLabelMachineName\Sdk\ApiClient;
use WhiteLabelMachineName\Sdk\ApiException;
use WhiteLabelMachineName\Sdk\ApiResponse;
use WhiteLabelMachineName\Sdk\Http\HttpRequest;
use WhiteLabelMachineName\Sdk\ObjectSerializer;

/**
 * TransactionMobileSdkService service
 *
 * @category Class
 * @package  WhiteLabelMachineName\Sdk
 * @author   WhiteLabelMachineName
 * @license  http://www.apache.org/licenses/LICENSE-2.0 Apache License v2
 */
class TransactionMobileSdkService {

	/**
	 * The API client instance.
	 *
	 * @var ApiClient
	 */
	private $apiClient;

	/**
	 * Constructor.
	 *
	 * @param ApiClient $apiClient the api client
	 */
	public function __construct(ApiClient $apiClient) {
		if (is_null($apiClient)) {
			throw new \InvalidArgumentException('The api client is required.');
		}

		$this->apiClient = $apiClient;
	}

	/**
	 * Returns the API client instance.
	 *
	 * @return ApiClient
	 */
	public function getApiClient() {
		return $this->apiClient;
	}


	/**
	 * Operation paymentFormUrl
	 *
	 * Build Mobile SDK URL
	 *
	 * @param string $credentials The credentials identifies the transaction and contains the security details which grants the access this operation. (required)
	 * @throws \WhiteLabelMachineName\Sdk\ApiException
	 * @throws \WhiteLabelMachineName\Sdk\VersioningException
	 * @throws \WhiteLabelMachineName\Sdk\Http\ConnectionException
	 * @return string
	 */
	public function paymentFormUrl($credentials) {
		return $this->paymentFormUrlWithHttpInfo($credentials)->getData();
	}

	/**
	 * Operation paymentFormUrlWithHttpInfo
	 *
	 * Build Mobile SDK URL
     
     *
	 * @param string $credentials The credentials identifies the transaction and contains the security details which grants the access this operation. (required)
	 * @throws \WhiteLabelMachineName\Sdk\ApiException
	 * @throws \WhiteLabelMachineName\Sdk\VersioningException
	 * @throws \WhiteLabelMachineName\Sdk\Http\ConnectionException
	 * @return ApiResponse
	 */
	public function paymentFormUrlWithHttpInfo($credentials) {
		// verify the required parameter 'credentials' is set
		if (is_null($credentials)) {
			throw new \InvalidArgumentException('Missing the required parameter $credentials when calling paymentFormUrl');
		}
		// header params
		$headerParams = [];
		$headerAccept = $this->apiClient->selectHeaderAccept(['text/plain;charset=utf-8', 'application/json']);
		if (!is_null($headerAccept)) {
			$headerParams[HttpRequest::HEADER_KEY_ACCEPT] = $headerAccept;
		}
		$headerParams[HttpRequest::HEADER_KEY_CONTENT_TYPE] = $this->apiClient->selectHeaderContentType([]);

		// query params
		$queryParams = [];
		if (!is_null($credentials)) {
			$queryParams['credentials'] = $this->apiClient->getSerializer()->toQueryValue($credentials);
		}

		// path params
		$resourcePath = '/transaction-mobile-sdk/payment-form-url';
		// default format to json
		$resourcePath = str_replace('{format}', 'json', $resourcePath);

		// form params
		$formParams = [];
		
		// for model (json/xml)
		$httpBody = '';
		if (isset($tempBody)) {
			$httpBody = $tempBody; // $tempBody is the method argument, if present
		} elseif (!empty($formParams)) {
			$httpBody = $formParams; // for HTTP post (form)
		}
		// make the API Call
		try {
			$response = $this->apiClient->callApi(
				$resourcePath,
				'GET',
				$queryParams,
				$httpBody,
				$headerParams,
				'string',
				'/transaction-mobile-sdk/payment-form-url'
            );
			return new ApiResponse($response->getStatusCode(), $response->getHeaders(), $this->apiClient->getSerializer()->deserialize($response->getData(), 'string', $response->getHeaders()));
		} catch (ApiException $e) {
			switch ($e->getCode()) {
                case 200:
                    $data = ObjectSerializer::deserialize(
                        $e->getResponseBody(),
                        'string',
                        $e->getResponseHeaders()
                    );
                    $e->setResponseObject($data);
                break;
                case 409:
                    $data = ObjectSerializer::deserialize(
                        $e->getResponseBody(),
                        '\WhiteLabelMachineName\Sdk\Model\ClientError',
                        $e->getResponseHeaders()
                    );
                    $e->setResponseObject($data);
                break;
                case 442:
                    $data = ObjectSerializer::deserialize(
                        $e->getResponseBody(),
                        '\WhiteLabelMachineName\Sdk\Model\ClientError',
                        $e->getResponseHeaders()
                    );
                    $e->setResponseObject($data);
                break;
                case 542:
                    $data = ObjectSerializer::deserialize(
                        $e->getResponseBody(),
                        '\WhiteLabelMachineName\Sdk\Model\ServerError',
                        $e->getResponseHeaders()
                    );
                    $e->setResponseObject($data);
                break;
			}
			throw $e;
		}
	}


}
